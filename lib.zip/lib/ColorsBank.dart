// MY BANK OF COLORS
import 'package:flutter/material.dart';

const stuYellow = Color(0xfff7d218);
const stuFadeYellow = Color(0xfffae579);
const stuBlue = Color(0xff0073ac);
const stuLightBlue = Color(0xffd1e2f6);
const stuMiddleBlue = Color(0xffe9f1fb);
const stuWhite = Color(0xfffafafa);
