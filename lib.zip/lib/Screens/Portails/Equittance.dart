import 'package:flutter/material.dart';

class Equittance extends StatefulWidget {
  Equittance({Key? key}) : super(key: key);

  @override
  _EquittanceState createState() => _EquittanceState();
}

class _EquittanceState extends State<Equittance> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.blue[900],
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(Icons.arrow_back_ios_new),
        ),
      ),
      body: Container(
        child: Center(
          child: Text(
            "Portail eQuittance",
            style: TextStyle(
              fontSize: 20,
              color: Color(0xff344051),
            ),
          ),
        ),
      ),
    );
  }
}
