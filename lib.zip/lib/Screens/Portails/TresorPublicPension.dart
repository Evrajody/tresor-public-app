import 'package:flutter/material.dart';

class TresorPublicPension extends StatefulWidget {
  TresorPublicPension({Key? key}) : super(key: key);

  @override
  _TresorPublicPensionState createState() => _TresorPublicPensionState();
}

class _TresorPublicPensionState extends State<TresorPublicPension> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.blue[900],
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(Icons.arrow_back_ios_new),
        ),
      ),
      body: Container(
        child: Center(
          child: Text(
            "Portail fiche pension",
            style: TextStyle(
              fontSize: 20,
              color: Color(0xff344051),
            ),
          ),
        ),
      ),
    );
  }
}
