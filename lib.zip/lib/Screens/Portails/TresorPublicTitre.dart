import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class TresorPublicTitre extends StatefulWidget {
  @override
  _TresorPublicTitreState createState() => _TresorPublicTitreState();
}

class _TresorPublicTitreState extends State<TresorPublicTitre> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.blue[900],
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(Icons.arrow_back_ios_new),
        ),
      ),
      body: Container(
        child: Center(
          child: Text(
            "Portail suivie titre",
            style: TextStyle(
              fontSize: 20,
              color: Color(0xff344051),
            ),
          ),
        ),
      ),
    );
  }
}
