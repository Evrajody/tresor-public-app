import 'package:flutter/material.dart';

class TresorPublicChange extends StatefulWidget {
  @override
  _TresorPublicChangeState createState() => _TresorPublicChangeState();
}

class _TresorPublicChangeState extends State<TresorPublicChange> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.blue[900],
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(Icons.arrow_back_ios_new),
        ),
      ),
      body: Container(
        child: Center(
          child: Text(
            "Portail suivie change",
            style: TextStyle(
              fontSize: 20,
              color: Color(0xff344051),
            ),
          ),
        ),
      ),
    );
  }
}
